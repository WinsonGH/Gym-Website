function submission(){
  var validation = true;
  if (!checkEmail()){
    validation = false;
    alert("Needs Real Email");
  }
  if (!checkAge()){
    validation = false;
    alert("Invalid Age");
  }
  if (!checkPNumber()){
    validation = false;
    alert("Put in a 10-digit Phone Number");
  }
  if (!checkTrainer()){
    validation=false;
    alert("Choose a Trainer Preference");
  }
  if (validation){
    alert("You Did It!");
  }
}

function checkEmail(){
  var email = document.getElementById('email').value;
  if (email.includes('@')){
    return true;
  } else {
    return false;
  }
}

function checkPNumber(){
  var pNumber = document.getElementById('phone').value;
  if (!isNaN(pNumber)){
    if (pNumber.length == 10){
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function checkAge(){
  var age = document.getElementById('age').value;
  if (!isNaN(age)){
    if (age > 15){
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function checkTrainer(){
  var trainer = document.querySelector('input[name="trainer"]:checked');
  if (trainer){
    return true;
  } else {
    return false;
  }
}
